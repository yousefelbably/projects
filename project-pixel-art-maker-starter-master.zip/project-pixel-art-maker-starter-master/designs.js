// Select color input
// Select size input

// When size is submitted by the user, call makeGrid()

function makeGrid() {

   
        
        var height = document.getElementById("inputHeight").value
        var width = document.getElementById("inputWidth").value;
        
        
        var table = document.getElementById("pixelCanvas");
    
        var x = " ";
    
        for(var i = 0; i < height; i++){
    
            x += "<tr>";
    
            for(var j = 0;j< width;j++){
    
                x += "<td></td>";
    
            }
    
            x += "</tr>";
    
        }
    
        table.innerHTML = x; 
    }
        
    function colorIt (){ 
    
        var td = document.querySelectorAll("td");
          
    for (var u = 0 ; u < td.length  ; u++ ){
    
        td[u].addEventListener("click" , function (event){ 
    
             var colorCell = event.target ; 
    
             colorCell.style.backgroundColor = document.getElementById("colorPicker").value ;
    
        })
    }
    
    }
        
        document.addEventListener("submit" , function(){ 
    
     event.preventDefault();
    
    makeGrid();         
     
    colorIt();
        
        } ); 
        
      
