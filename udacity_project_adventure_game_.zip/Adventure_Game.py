import time  # import time is to slow down the appearnce of scentences
import random  # import random is to choose randomly between several objects
# all objects in the game
places = ['Abandoned house' + 'or forest']
weapons = ['knife', 'gun']
Forest_monester = ['lion', 'tiger']
abandonedshouse_monester = ['zombies']
Game_fight = ['fight', 'escape from monester']
Game_result = ['you Won', 'you Lost']
number = ['1', '2']
# End of all objects in the game


def finalfight():
    Game_fight = ''
    while Game_fight not in number:  # \n
        Game_fight = input('Are you going to fight or escape?'
                           '(if you are going to attack press"1")\n'
                           '("if you are going to escape press"2")\n')
    if Game_fight == '1':  # \n
        print('you won')
    elif Game_fight == '2':
        print('you lost')


def Monsters(choice):
    if choice == 'forest':
        print(random.choice(Forest_monester))
    if choice == 'Abandoned house':  # \n
        print(random.choice(abandonedshouse_monester))


def printsleep(msg, seconds):
    print(msg)
    time.sleep(seconds)


def changeweapon():
    changerequest = ''
    while changerequest not in number:
        changerequest = input('would you like to change your weapon?\n'
                              'if yes press 1, if no press 2 \n')
    if changerequest == '1':
        weapontaken = random.choice(weapons)
    #  game will start


UnfinishedGame = 'y'
while UnfinishedGame == 'y':
    printsleep('welcome to adventure_game', 2)
    printsleep('we will take you to another world of enjoy and fun .', 2)
    name = input('please enter your name to start the game .\n')
    printsleep('ok ' + name + ', You found yourself standing'
               'on a crossroad with tow ways .', 2)
    print('please choose wich way you will take\n')
    for x in places:
        print(x)
    choice = ''
    while choice not in number:
        choice = input('plesae adjust your choice \n'
                       '(to choose forest press 1)\n)'
                       '(to choose Abandoned house press 2)\n')
    if choice == '1':
        choice = 'forest'
    elif choice == '2':
        choice = 'Abandoned house'
        time.sleep(2)
        print('your weapon is the ')
    weapontaken = random.choice(weapons)
    print(weapontaken)
    changeweapon()
    time.sleep(2)
    printsleep('ok,  you are now in ' + choice +
               ' and your weapon now is '
               + weapontaken + '\n', 2)
    time.sleep(3)
    print('now while moving in the forest you faced ')
    Monsters(choice)
    time.sleep(2)
    print('you have to use your weapon to kill the monster')
    time.sleep(2)
    finalfight()
    time.sleep(2)
    print('Game over')
    time.sleep(3)
    UnfinishedGame = input('would you like to try again? for yes write y,'
                           'for no write n\n')
